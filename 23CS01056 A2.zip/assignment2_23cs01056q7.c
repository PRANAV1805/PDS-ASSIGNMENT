#include<stdio.h>
int main()
{
int mealcost ,tipPercent , taxPercent;

printf("Enter the mealcost,tipPercent , taxPercent ");
scanf("%d %d %d",&mealcost,&tipPercent,&taxPercent);

int Totalcost = mealcost + (mealcost*tipPercent)/100 + (mealcost * taxPercent)/100;


printf("total cost = %d", Totalcost);


return 0;

}
