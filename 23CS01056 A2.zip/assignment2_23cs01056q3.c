#include<stdio.h>
int main()
{
    int num;
    printf("enter a number");
    scanf("%d",&num);
    int year;
    year=num/365;
    
    int a;
    a=num-365*year;
    int month;
    month=a/30;
    int b;
    b=num-365*year-30*month;

    int week;
    week=b/7;
    int days;
    days=num-365*year-30*month-7*week;
    printf( "year = %d \nmonth= %d \nweek=%d \ndays=%d \n",year,month,week,days);
    return 0;

    


}