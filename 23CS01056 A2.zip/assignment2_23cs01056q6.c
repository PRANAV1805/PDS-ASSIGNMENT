
#include <stdio.h>

int main() {
    int number;

    
    printf("Enter an integer: ");
    scanf("%d", &number);

    
    
 (number >= 100 && number <= 200) ?
  (number % 2 != 0 ? printf("The number is odd and within the range.\n") : printf("The number is not odd.\n")) :
  printf("The number is not within the range.\n");

    return 0;
}



