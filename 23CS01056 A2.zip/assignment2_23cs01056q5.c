#include<stdio.h>
int main()
{
    int a;
    printf("enter a number");
    scanf("%d",&a);
    if(a & 1)
    {
        printf("given number is odd");
    }
        else
        {
            printf("given number is even");
        }
     return 0;   

    }

     

    

